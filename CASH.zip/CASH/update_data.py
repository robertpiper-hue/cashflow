import mysql.connector

# Database connection details
DB_HOST = 'sql301.infinityfree.com'
DB_NAME = 'if0_38627238_cash_name'
DB_USER = 'if0_38627238'
DB_PASSWORD = 'f7B7h1lwdR3DIP1'

# Connect to the database
connection = mysql.connector.connect(
    host=DB_HOST,
    database=DB_NAME,
    user=DB_USER,
    password=DB_PASSWORD
)

cursor = connection.cursor()

# SQL query to create the transactions table
create_table_query = '''
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    date DATE NOT NULL,
    description VARCHAR(255),
    amount DECIMAL(10, 2) NOT NULL,
    type ENUM('income', 'expense') NOT NULL,
    category VARCHAR(100)
);
'''

# Execute the table creation query
cursor.execute(create_table_query)

# Commit the changes
connection.commit()

print("Transactions table created successfully.")

# Example query to fetch data
query = "SELECT * FROM your_table_name"
cursor.execute(query)

# Fetch and print the results
results = cursor.fetchall()
for row in results:
    print(row)

# Close the cursor and connection
cursor.close()
connection.close()
