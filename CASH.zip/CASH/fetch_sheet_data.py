import gspread
from oauth2client.service_account import ServiceAccountCredentials
import json

# Google Sheets API setup
SCOPE = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
CREDS = ServiceAccountCredentials.from_json_keyfile_name('credentials.json', SCOPE)
CLIENT = gspread.authorize(CREDS)

# Fetch data from Google Sheet
SHEET_URL = 'https://docs.google.com/spreadsheets/d/1vwX1fH0o8o1GaaXAVdX4Wulwe4agKGBV5KpDFGJ5Kxo/edit#gid=0'
SHEET = CLIENT.open_by_url(SHEET_URL).sheet1
DATA = SHEET.get_all_records()

# Generate JSON file
with open('cashflow2140.json', 'w') as file:
    json.dump(DATA, file, indent=4)

print('JSON file generated successfully!')
